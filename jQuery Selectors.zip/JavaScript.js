// find elements
var banner = $("#banner-message")
var button = $("button")

// handle click and log the value in consoles
button.on("click", function(){
  console.log($("p"));
  console.log($("#paraContent"));
  console.log($(".paraClass"));
})